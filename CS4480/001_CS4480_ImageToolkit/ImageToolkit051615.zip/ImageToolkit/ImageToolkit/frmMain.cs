﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
//using ImageToolkit.ImageForms;

/* * * * *
 * Fun instructions will go here.
 * Have a nice day.
 * */


namespace ImageToolkit
{
    
    public partial class frmMain : Form
    {
        List<frmStandard> openImages;
        public frmMain()
        {
            InitializeComponent();
            openImages = new List<frmStandard>();
        }

        public void remove(frmStandard item)
        {
            openImages.Remove(item);
            lstImages.Items.Remove(item.ToString());
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            DialogResult result;
            frmStandard frm;
            string filename;

            try
            {
                openFileDialog.Filter = MyConstants.FILE_FILTER_IN;
                openFileDialog.FilterIndex = MyConstants.FILTER_INDEX;

                result = openFileDialog.ShowDialog();

                if (result == DialogResult.OK)
                {
                    filename = openFileDialog.FileName;
                    Bitmap image = new Bitmap(filename);
                    string imageName = Path.GetFileName(filename);
                    frm = new frmStandard(imageName, image, this);
                    frm.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.mainFormClosing);
                    frm.Show();
                    int index = lstImages.Items.Add(frm.ToString());
                    openImages.Add(frm);
                    lstImages.SelectedIndex = index;
                }
            }
            catch (Exception ex)
            {
                ErrorMessage.Display(ex, "frmImageColorRGB(filename)");
            }
             
        }

        private void mainFormClosing(object sender, FormClosingEventArgs e)
        {
            // Do stuff
        }

        private void openImageForm(object sender, EventArgs e)
        {
            foreach (string s in lstImages.SelectedItems)
            {
                foreach (frmStandard f in this.openImages)
                    if (s == f.ToString())
                        f.Show();
            }
        }

        private void toolStripMenuSaveAs_Click(object sender, EventArgs e)
        {
            foreach (string s in lstImages.SelectedItems)
            {
                foreach (frmStandard f in this.openImages)
                    f.saveImage();
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (string s in lstImages.SelectedItems)
            {
                foreach (frmStandard f in this.openImages)
                    f.saveToolStripMenuItem_Click(sender,e);
            }
            
        }

        public void updatelstImages(string oldName, string newName)
        {
            int insertPt = lstImages.Items.IndexOf(oldName);
            lstImages.Items.Remove(oldName);
            lstImages.Items.Add(newName);
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (string s in lstImages.SelectedItems)
            {
                foreach (frmStandard f in this.openImages)
                {
                    if (s == f.ToString())
                    {
                        f.Close();
                        return;
                    }
                }

            }
        }

        private void closeAllToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            while (openImages.Any())
            {
                frmStandard f = openImages.First();
                f.Close();
            }
         
        }

        private void tvwOperations_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstImages.Items.Count; i++)
                lstImages.SetSelected(i, true);
        }

        private void unselectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstImages.Items.Count; i++)
                lstImages.SetSelected(i, false);
        }
    }
    public static class MyConstants
    {
        public const String FILE_FILTER_IN = "Image Files(*.BMP; *.JPG; *.GIF; *.TIF; *.TIFF)|*.BMP;*.JPG;*.GIF;*.TIF;*.TIFF|All Files|*.*";
        public const String FILE_FILTER_OUT = "Bitmap (*.bmp)|*.bmp|JPEG (*.jpg)|*.jpg|GIF (*.gif)|*.gif|TIF (*.tif)|*.tif|TIFF (*.tiff)|*.tiff";
        public const int FILTER_INDEX = 1;
    }
    public static class ErrorMessage
    {
        public static void Display(Exception ex, String source)
        {
            if (ex is ApplicationException) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
            else MessageBox.Show(ex.Message + "\n" + ex.StackTrace, "Error at " + source, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
