﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageToolkit
{
    class ExecutionStack
    {
        List<IOperand> stack;
        frmMain mainForm;
        ListBox ls;
        public ExecutionStack(frmMain m)
        {
            mainForm = m;
            ls = mainForm.getStack();
            stack = new List<IOperand>();
        }

        public IOperand X
        {
            get
            {
                if (ls.Items.Count >= 1)
                    return (IOperand)ls.Items[0];
                else
                    return null;
            }
        }
        
        public IOperand Y
        {
            get
            {
                if (ls.Items.Count >= 2)
                    return (IOperand)ls.Items[1];
                else
                    return null;
            }
        }

        public void Push(IOperand op)
        {
            if (op != null)
            {
                ls.Items.Insert(0, op.ToString());
                stack.Insert(0,op);
            }
            ls.Refresh();
        }

        public IOperand Pop()
        {
            IOperand temp = null;
            if (ls.Items.Count >= 1)
            {
                temp = stack[0];
                ls.Items.RemoveAt(0);
                ls.Refresh();
            }
            return temp;
        }

        public void ClearAll()
        {
            while (Pop() != null) ;
        }

        public void SwapXY()
        {
            if (ls.Items.Count >= 2)
            {
                object temp = ls.Items[0];
                ls.Items[0] = ls.Items[1];
                ls.Items[1] = temp;
                IOperand temp2 = stack[0];
                stack[0] = stack[1];
                stack[1] = temp2;
            }
        }

        public void Remove(IOperand op)
        {
            ls.Items.Remove(op);
        }

        public void RemoveAll()
        {
            ls.Items.Clear();
            stack.Clear();
        }

    }
}
