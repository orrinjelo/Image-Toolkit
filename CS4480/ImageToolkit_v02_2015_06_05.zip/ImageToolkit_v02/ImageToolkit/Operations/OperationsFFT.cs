﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace ImageToolkit.Operations
{
    struct Complex
    {
        public float real, imag;
        public Complex(float x, float y)
        {
            real = x;
            imag = y;
        }

        public float Magnitude()
        {
            return ((float)Math.Sqrt(real * real + imag * imag));
        }

        public float Phase()
        {
            return ((float)Math.Atan(imag / real));
        }
    }

    public static class OperationsFFT
    {
        public static void RegisterOperations()
        {
            OperationRegistry.RegisterOperation(new Operation("Frequency Domain Filters", "DFT", "DFT(X)", FFT, true));
        }

        private static void FFT1D(int dir, int m, ref float[] x, ref float[] y)
        {
            long nn, i, i1, j, k, i2, l, l1, l2;
            float c1, c2, tx, ty, t1, t2, u1, u2, z;
            nn = 1;
            for (i = 0; i < m; i++)
            {
                nn *= 2;
            }

            i2 = nn >> 1;
            j = 0;

            for (i=0; i<nn-1; i++)
            {
                if (i<j)
                {
                    tx = x[i];
                    ty = y[i];
                    x[i] = x[j];
                    y[i] = y[j];
                    x[j] = tx;
                    y[j] = ty;
                }
                k = i2;
                while (k <= j)
                {
                    j -= k;
                    k >>= 1;
                }
                j += k;
            }

            c1 = -1f;
            c2 = 0f;
            l2 = 1;
            for (l=0; l<m; l++)
            {
                l1 = l2;
                l2 <<= 1;
                u1 = 1f;
                u2 = 0f;
                for (j=0; j<l1; j++)
                {
                    for (i = j; i < nn; i += l2)
                    {
                        i1 = i + l1;
                        t1 = u1 * x[i1] - u2 * y[i1];
                        t2 = u1 * y[i1] + u2 * x[i1];
                        x[i1] = x[i] - t1;
                        y[i1] = y[i] - t2;
                        x[i] += t1;
                        y[i] += t2;
                    }
                    z = u1 * c1 - u2 * c2;
                    u2 = u1 * c2 + u2 * c1;
                    u1 = z;
                }
                c2 = (float)Math.Sqrt((1f - c1) / 2f);
                if (dir == 1) c2 = -c2;
                c1 = (float)Math.Sqrt((1f + c1) / 2f);

            }
            if (dir == 1)
            {
                for (i = 0; i < nn; i++)
                {
                    x[i] /= (float)nn;
                    y[i] /= (float)nn;
                }
            }
        }

        private static Complex[,] FFT2D(Complex[,] c, int nx, int ny, int dir)
        {
            int i, j, m;
            float[] real, imag;
            Complex[,] output = c;
            real = new float[nx];
            imag = new float[nx];

            for (j=0; j<ny; j++)
            {
                for (i=0; i<nx; i++)
                {
                    real[i] = c[i,j].real;
                    imag[i] = c[i,j].imag;
                }

                // 1D FFT on rows
                m = (int)Math.Log((double)nx, 2);
                FFT1D(dir, m, ref real, ref imag);
                for (i = 0; i < nx; i++)
                {
                    output[i,j].real = real[i];
                    output[i,j].imag = imag[i];
                }
            }
            // Cols
            real = new float[ny];
            imag = new float[ny];

            for (i=0; i < nx; i++)
            {
                for (j=0; j<ny; j++)
                {
                    real[j] = output[i, j].real;
                    imag[j] = output[i, j].imag;
                }
                // 1D FFT on cols
                m = (int)Math.Log((double)ny, 2);
                FFT1D(dir, m, ref real, ref imag);
                for (j=0; j<ny; j++)
                {
                    output[i, j].real = real[j];
                    output[i, j].imag = imag[j];
                }
            }
            return output;
        }

        public static void FFT()
        {
            FFT(null, true);
        }

        public static void FFT(IOperand x=null, bool spawn=true)
        {
            if (x == null) x = ExecutionStack.X;
            if (x == null) return;
            Bitmap bmp = x.GetBitmap();
            float[][][] img = Normalize.ToFloat(bmp);
            float[][][] fftimg = new float[3][][];
            float[][][] fftlog = new float[3][][];
            float[][][] fftphaselog = new float[3][][];
            float[][][] fmagnitude = new float[3][][];
            float[][][] fphase = new float[3][][];
            float[][][] fnorm = new float[3][][];
            float[][][] fphasenorm = new float[3][][];

            int W = bmp.Width, H = bmp.Height;
            Complex[,] Fourier = new Complex[H,W];
            Complex[,] Output = new Complex[H,W];


            for (int i=0; i < W; i++)
                for (int j=0; j < H; j++)
                {
                    Fourier[j,i].real = 0f;
                    Fourier[j,i].imag = 0f;
                }

            for (int c = 0; c < 3; c++)
            {
                fftimg[c] = new float[H][];
                fftlog[c] = new float[H][];
                fftphaselog[c] = new float[H][];
                fmagnitude[c] = new float[H][];
                fphase[c] = new float[H][];
                fnorm[c] = new float[H][];
                fphasenorm[c] = new float[H][];

                for (int j = 0; j < H; j++)
                {
                    fftimg[c][j] = new float[W];
                    fftlog[c][j] = new float[W];
                    fftphaselog[c][j] = new float[W];
                    fmagnitude[c][j] = new float[W];
                    fphase[c][j] = new float[W];
                    fnorm[c][j] = new float[W];
                    fphasenorm[c][j] = new float[W];
                    for (int i = 0; i < W; i++)
                    {
                        Fourier[j, i].real += img[c][j][i] / 3f;
                    }
                }
            }

            Output = FFT2D(Fourier, H, W, 1);
            float max = 0f;
            for (int c = 0; c < 3; c++)
                for (int j = 0; j < H; j++)
                    for (int i = 0; i < W; i++)
                    {
                        fmagnitude[c][j][i] = Output[j, i].Magnitude();
                        fphase[c][j][i] = Output[j, i].Phase();
                        fftlog[c][j][i] = (float)Math.Log(1 + fmagnitude[c][j][i]);
                        fftphaselog[c][j][i] = (float)Math.Log(1 + Math.Abs(fphase[c][j][i]));
                    }

            max = fftlog[0][0][0];
            for (int i = 0; i < W; i++ )
                for (int j=0; j<H; j++)
                {
                    if (fftlog[0][j][i] > max) max = fmagnitude[0][j][i];
                }
            for (int c = 0; c < 3; c++)
                for (int j = 0; j < H; j++)
                    for (int i = 0; i < W; i++)
                    {
                        fftimg[c][j][i] = fmagnitude[c][j][i] / max;
                    }

           // MessageBox.Show("Max : " + max.ToString());

            if (spawn) x.CreateSibling(fftimg, "FFT of " + bmp.ToString());
            else ((frmStandard)x).Image = Normalize.FromFloat(fftimg);
        }
    }
}
