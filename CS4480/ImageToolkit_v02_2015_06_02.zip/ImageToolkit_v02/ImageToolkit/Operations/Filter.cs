﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageToolkit.Operations
{
    /*
     * float[][] filter = new float[][] { { 0f, -1f, 0f }, { -1f, 4f, -1f }, { 0f, -1f, 0f } };
    result[h][w] = 
    (filter[fh - 1][fw - 1] * p[h - 1][w - 1] + filter[fh - 1][fw] * p[h - 1][w] + filter[fh - 1][fw + 1] * p[h - 1][w + 1] +
    filter[fh][fw - 1] * p[h][w - 1] + filter[fh][fw] * p[h][w] + filter[fh][fw + 1] * p[h][w + 1] +
    filter[fh + 1][fw - 1] * p[h + 1][w - 1] + filter[fh + 1][fw] * p[h + 1][w] + filter[fh + 1][fw + 1] * p[h + 1][w + 1]);
     */
    class Filter
    {
        float[][] filter
        { get; set; }
        public Filter(float[] f)
        {
            filter = new float[3][];
            for (int i=0; i<3; i++)
            {
                filter[i] = new float[3];
                for (int j=0; j<3; j++)
                {
                    filter[i][j] = f[3 * i + j];
                }
            }
        }

        public float[][][] Apply(float[][][] f, int H, int W)
        {
            float[][][] result = new float[3][][];
            for (int c = 0; c < 3; c++)
            {
                result[c] = new float[H][];
                for (int h = 0; h < H; h++)
                {
                    result[c][h] = new float[W];

                    for (int w = 0; w < W; w++)
                    {
                        result[c][h][w] = (h > 0 && w > 0 ? filter[0][0] * f[c][h - 1][w - 1] : f[c][h][w]) + (h > 0 ? filter[0][1] * f[c][h - 1][w] : f[c][h][w]) + (h > 0 && w + 1 < W ? filter[0][2] * f[c][h - 1][w + 1] : f[c][h][w])
                            + (w > 0 ? filter[1][0] * f[c][h][w - 1] : f[c][h][w]) + filter[1][1] * f[c][h][w] + (w + 1 < W ? filter[1][2] * f[c][h][w + 1] : f[c][h][w])
                            + (h + 1 < H && w > 0 ? filter[2][0] * f[c][h + 1][w - 1] : f[c][h][w]) + (h + 1 < H ? filter[2][1] * f[c][h + 1][w] : f[c][h][w]) + (h + 1 < H && w + 1 < W ? filter[2][2] * f[c][h + 1][w + 1] : f[c][h][w]);
                        result[c][h][w] = (float)Math.Abs(result[c][h][w]);
                    }
                }
            }
            return result;
        }
    }
}
