﻿namespace ImageToolkit.Operations
{
    partial class frmRotate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbCW = new System.Windows.Forms.RadioButton();
            this.rbCCW = new System.Windows.Forms.RadioButton();
            this.rbFlip = new System.Windows.Forms.RadioButton();
            this.rbArbitrary = new System.Windows.Forms.RadioButton();
            this.udAngle = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.udAngle)).BeginInit();
            this.SuspendLayout();
            // 
            // rbCW
            // 
            this.rbCW.AutoSize = true;
            this.rbCW.Location = new System.Drawing.Point(13, 13);
            this.rbCW.Name = "rbCW";
            this.rbCW.Size = new System.Drawing.Size(92, 17);
            this.rbCW.TabIndex = 0;
            this.rbCW.TabStop = true;
            this.rbCW.Text = "Clockwise 90°";
            this.rbCW.UseVisualStyleBackColor = true;
            this.rbCW.Click += new System.EventHandler(this.disableAngleBox);
            // 
            // rbCCW
            // 
            this.rbCCW.AutoSize = true;
            this.rbCCW.Location = new System.Drawing.Point(13, 37);
            this.rbCCW.Name = "rbCCW";
            this.rbCCW.Size = new System.Drawing.Size(131, 17);
            this.rbCCW.TabIndex = 1;
            this.rbCCW.TabStop = true;
            this.rbCCW.Text = "Counter-clockwise 90°";
            this.rbCCW.UseVisualStyleBackColor = true;
            this.rbCCW.Click += new System.EventHandler(this.disableAngleBox);
            // 
            // rbFlip
            // 
            this.rbFlip.AutoSize = true;
            this.rbFlip.Location = new System.Drawing.Point(13, 61);
            this.rbFlip.Name = "rbFlip";
            this.rbFlip.Size = new System.Drawing.Size(82, 17);
            this.rbFlip.TabIndex = 2;
            this.rbFlip.TabStop = true;
            this.rbFlip.Text = "Rotate 180°";
            this.rbFlip.UseVisualStyleBackColor = true;
            this.rbFlip.Click += new System.EventHandler(this.disableAngleBox);
            // 
            // rbArbitrary
            // 
            this.rbArbitrary.AutoSize = true;
            this.rbArbitrary.Location = new System.Drawing.Point(13, 85);
            this.rbArbitrary.Name = "rbArbitrary";
            this.rbArbitrary.Size = new System.Drawing.Size(129, 17);
            this.rbArbitrary.TabIndex = 3;
            this.rbArbitrary.TabStop = true;
            this.rbArbitrary.Text = "Rotate arbitrary angle:";
            this.rbArbitrary.UseVisualStyleBackColor = true;
            this.rbArbitrary.Click += new System.EventHandler(this.enableAngleBox);
            // 
            // udAngle
            // 
            this.udAngle.Enabled = false;
            this.udAngle.Location = new System.Drawing.Point(149, 85);
            this.udAngle.Maximum = new decimal(new int[] {
            181,
            0,
            0,
            0});
            this.udAngle.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            -2147483648});
            this.udAngle.Name = "udAngle";
            this.udAngle.Size = new System.Drawing.Size(120, 20);
            this.udAngle.TabIndex = 4;
            this.udAngle.ValueChanged += new System.EventHandler(this.checkIfBoundary);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 111);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(260, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmRotate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 145);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.udAngle);
            this.Controls.Add(this.rbArbitrary);
            this.Controls.Add(this.rbFlip);
            this.Controls.Add(this.rbCCW);
            this.Controls.Add(this.rbCW);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmRotate";
            this.Text = "Rotate";
            ((System.ComponentModel.ISupportInitialize)(this.udAngle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbCW;
        private System.Windows.Forms.RadioButton rbCCW;
        private System.Windows.Forms.RadioButton rbFlip;
        private System.Windows.Forms.RadioButton rbArbitrary;
        private System.Windows.Forms.NumericUpDown udAngle;
        private System.Windows.Forms.Button button1;
    }
}