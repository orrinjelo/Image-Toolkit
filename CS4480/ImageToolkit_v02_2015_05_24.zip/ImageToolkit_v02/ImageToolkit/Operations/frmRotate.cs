﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageToolkit.Operations
{
    public partial class frmRotate : Form
    {
        public frmRotate()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (this.rbCW.Checked) OperationsTransformations.Rotate(90);
            else if (this.rbCCW.Checked) OperationsTransformations.Rotate(-90);
            else if (this.rbFlip.Checked) OperationsTransformations.Rotate(180);
            else OperationsTransformations.Rotate(Convert.ToInt32(this.udAngle.Value));
            this.Close();
        }

        private void checkIfBoundary(object sender, EventArgs e)
        {
            if (this.udAngle.Value == 181) this.udAngle.Value = -179;
            else if (this.udAngle.Value == -180) this.udAngle.Value = 180;
        }

        private void enableAngleBox(object sender, EventArgs e)
        {
            this.udAngle.Enabled = true;
        }

        private void disableAngleBox(object sender, EventArgs e)
        {
            this.udAngle.Enabled = false;
        }
    }
}
